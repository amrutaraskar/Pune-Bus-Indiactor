package com.devproject;


import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class busentry extends Activity implements OnClickListener
{
	EditText editBusno,editBustiming;
	Button btnAdd,btnViewAll,btnDelete;
	SQLiteDatabase db;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.busentry);
        
        editBusno=(EditText)findViewById(R.id.editBusno);
        editBustiming=(EditText)findViewById(R.id.editBustiming);
        
        btnAdd=(Button)findViewById(R.id.btnAdd);
        
        btnViewAll=(Button)findViewById(R.id.btnViewAll);
        btnAdd.setOnClickListener(this);
        
        btnViewAll.setOnClickListener(this);
        
        db=openOrCreateDatabase("BusDB1.db", Context.MODE_PRIVATE, null);
		db.execSQL("CREATE TABLE IF NOT EXISTS bus(busno VARCHAR NOT NULL,timings VARCHAR NOT NULL);");
    }
    public void onClick(View view)
    {
    	if(view==btnAdd)
    	{
    		if(editBusno.getText().toString().trim().length()==0||
    		   editBustiming.getText().toString().trim().length()==0)
    		{
    			showMessage("Error", "Please enter all values");
    			return;
    		}
    		
    		Cursor c=db.rawQuery("SELECT * FROM bus WHERE busno='"+editBusno.getText()+"' AND timings='"+editBustiming.getText()+"'", null);
    		if(c.getCount()==0)
    		{
    			db.execSQL("INSERT INTO bus VALUES('"+editBusno.getText()+"','"+editBustiming.getText()+
				   "');");
		         showMessage("Success", "Record added");
		         clearText();
    		}
    		
    		else
    		{
    			showMessage("Error", "Record ALREADY EXSISTS Please Enter A");
    			return;
    		}
        
    	    
    	}
    	
    	if(view==btnDelete)
    	{
    		if(editBusno.getText().toString().trim().length()==0)
    		{
    			showMessage("Error", "Please enter Busno");
    			return;
    		}
    		Cursor c=db.rawQuery("SELECT * FROM bus WHERE rollno='"+editBusno.getText()+"'", null);
    		if(c.moveToFirst())
    		{
    			db.execSQL("DELETE FROM bus WHERE timings='"+editBustiming.getText()+"'");
    			showMessage("Success", "Record Deleted");
    		}
    		else
    		{
    			showMessage("Error", "Invalid Entry");
    		}
    		clearText();
    	}
    	
    	if(view==btnViewAll)
    	{
    		Cursor c=db.rawQuery("SELECT * FROM bus", null);
    		if(c.getCount()==0)
    		{
    			showMessage("Error", "No records found");
    			return;
    		}
    		StringBuffer buffer=new StringBuffer();
    		while(c.moveToNext())
    		{
    			buffer.append("Busno: "+c.getString(0)+"\n");
    			buffer.append("BusTiming: "+c.getString(1)+"\n");
    		}
    		showMessage("Bus Timings", buffer.toString());
    	}
    	db.close();
    }
    public void showMessage(String title,String message)
    {
    	Builder builder=new Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(title);
    	builder.setMessage(message);
    	builder.show();
	}
    public void clearText()
    {
    	editBusno.setText("");
    	editBustiming.setText("");
       }
}