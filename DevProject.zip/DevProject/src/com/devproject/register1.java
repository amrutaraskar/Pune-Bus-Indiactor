package com.devproject;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


	public class register1 extends Activity implements OnClickListener{
		EditText edittext1,edittext2;
		SQLiteDatabase db;
		
		public void onCreate(Bundle savedInstanceState) {
			
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.register1);
	        
	        edittext1=(EditText)findViewById(R.id.editUsername);
		      edittext2=(EditText)findViewById(R.id.editPassword);
		      
		      db=openOrCreateDatabase("Stdinfo.db", Context.MODE_PRIVATE, null);
			  db.execSQL("CREATE TABLE IF NOT EXISTS Stdinfo(username VARCHAR NOT NULL,password VARCHAR NOT NULL);");
	        	   
		}
	
	public void onregisterclick(View v){
		if(edittext1.getText().toString().trim().length()==0||
	    		   edittext2.getText().toString().trim().length()==0)
	    		{
	    			showMessage("Error", "Please enter all values");
	    			clearText();
	    			return;
	    		}
		
		final String username = edittext1.getText().toString();
		final String pass = edittext2.getText().toString();
	    		
	    		Cursor c=db.rawQuery("SELECT * FROM Stdinfo WHERE username='"+edittext1.getText()+"' AND password='"+edittext2.getText()+"'", null);
	    		
	    			if(c.getCount()==0)
	    			{
	    		      db.execSQL("INSERT INTO Stdinfo VALUES('"+edittext1.getText()+"','"+edittext2.getText()+
					   "');");
	    	
			          showMessage("Success", "Register Successfully. Now login");
			         
			         Intent i = new Intent(register1.this, login.class);
			 		 startActivity(i);	
	    		    }
	    		
	    		   else
	    		   {
	    			showMessage("Error", "Record ALREADY EXSISTS Please Enter Another Username");
	    			return;
	    		   }
	    			
	    			db.close();
	    		
	    		
	    		
	      }

	public void showMessage(String title,String message)
    {
    	Builder builder=new Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(title);
    	builder.setMessage(message);
    	builder.show();
	}
	
	
	public void clearText()
    {
    	edittext1.setText("");
    	edittext2.setText("");
       }
	
	public void onClick(DialogInterface arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}

}
