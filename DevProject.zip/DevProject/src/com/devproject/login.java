
package com.devproject;


import android.app.Activity;
import android.widget.EditText;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

public class login extends Activity implements OnClickListener{
	EditText edittext1,edittext2;
	SQLiteDatabase db;
	
	public void onCreate(Bundle savedInstanceState) {
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        
        edittext1=(EditText)findViewById(R.id.editUsername);
	      edittext2=(EditText)findViewById(R.id.editPassword);
	      
	      db=openOrCreateDatabase("Stdinfo.db", Context.MODE_PRIVATE, null);
        	   
	}
	public void onloginclick(View v){
	
    		if(edittext1.getText().toString().trim().length()==0||
    		   edittext2.getText().toString().trim().length()==0)
    		{
    			showMessage("Error", "Please enter all values");
    			clearText();
    			return;
    		}
    		
		if(edittext1.getText().toString().equals("admin") && edittext2.getText().toString().equals("admin"))
		   {
			Intent i1 = new Intent(login.this, adminmenu.class);
			startActivity(i1);
		 
		   }
		
		
		Cursor c = db.rawQuery("SELECT * FROM Stdinfo WHERE username='"+edittext1.getText()+"' AND password='"+edittext2.getText()+"'", null);
		
		if(c.getCount()==0)
		{
			showMessage("Error", "NO Record EXSISTS Please Cheak Details");
			clearText();
			return;
		}
		else
		{
				Intent i = new Intent(login.this, usermenu.class);
				startActivity(i);	
		}
		
		db.close();
		
		
	}
	
	public void onregisterclick(View v){
		
		Intent i = new Intent(login.this, register1.class);
		startActivity(i);	
	}
	
	 public void showMessage(String title,String message)
	    {
	    	Builder builder=new Builder(this);
	    	builder.setCancelable(true);
	    	builder.setTitle(title);
	    	builder.setMessage(message);
	    	builder.show();
		}
	 
	 public void clearText()
	    {
	    	edittext1.setText("");
	    	edittext2.setText("");
	       }
	public void onClick(DialogInterface dialog, int which) {
		// TODO Auto-generated method stub
		
	}
}