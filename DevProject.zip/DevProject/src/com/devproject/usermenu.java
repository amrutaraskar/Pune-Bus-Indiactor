package com.devproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class usermenu extends Activity{
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.usermenu);
    }

	public void onapplyforpassclick(View v){
    	if(v.getId() == R.id.button1){
    		Intent i = new Intent(usermenu.this, register.class);
    		startActivity(i);
    	}
    	
    }
 public void onrenewclick(View v){
    	if(v.getId() == R.id.button2){
    		Intent i = new Intent(usermenu.this,renew.class);
    		startActivity(i);
    	}
    	
    }
}
