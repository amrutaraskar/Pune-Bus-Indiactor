package com.devproject;

import android.os.Bundle;
import android.app.Activity;

public class clgpay extends Activity{
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.clgpay);
}
}
