package com.devproject;


import android.app.Activity;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class guideme extends Activity {
	String[] busstops={"Shivajinagar","Katraj", "KoregaonPark", "KalyaniNagar","Sangvi","New Sangvi","Kothrud", "Ambegaon","Narhe","KothrudDepot", "KalaKhadak"};
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guideme);
        AutoCompleteTextView actv = (AutoCompleteTextView)findViewById(R.id.autoCompleteTextView1);
        actv.setAdapter(new ArrayAdapter<String>(this,R.layout.list_details,busstops));
        AutoCompleteTextView dev = (AutoCompleteTextView)findViewById(R.id.autoCompleteTextView2);
        dev.setAdapter(new ArrayAdapter<String>(this,R.layout.list_details1,busstops));
        
	}
	 public void onsearchclick(View v){
	    	if(v.getId() == R.id.search){
	    		Intent i = new Intent(guideme.this, menu.class);
	    		startActivity(i);
	    	}
	    	
	    }

}
