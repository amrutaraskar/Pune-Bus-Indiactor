package com.devproject;

import android.app.Activity;
import android.view.View;
import android.content.Intent;
import android.os.Bundle;

public class menu extends Activity{
	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.menu);
	    }
	 public void onguidemeclick(View v){
	    	if(v.getId() == R.id.button2){
	    		Intent i = new Intent(menu.this, guideme.class);
	    		startActivity(i);
	    	}
	    	
	    }
	 public void ontimetableclick(View v){
	    	if(v.getId() == R.id.button3){
	    		Intent i = new Intent(menu.this,timetable.class);
	    		startActivity(i);
	    	}
	    	
	    }
	
	 public void onloginclick(View v){
	    	if(v.getId() == R.id.button4){
	    		Intent i = new Intent(menu.this,login.class);
	    		startActivity(i);
	    	}
	    	
	    }

}
