package com.devproject;

import android.app.Activity;
import android.view.View;
import android.content.Intent;
import android.os.Bundle;

public class adminmenu extends Activity{
	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.adminmenu);
	    }
	 public void ondatabaseclick(View v){
	    	if(v.getId() == R.id.button2){
	    		Intent i = new Intent(adminmenu.this, database.class);
	    		startActivity(i);
	    	}
	    	
	    }
	 public void onpasscheakclick(View v){
	    	if(v.getId() == R.id.button3){
	    		Intent i = new Intent(adminmenu.this,passcheak.class);
	    		startActivity(i);
	    	}
	    	
	    }
	
	 public void onbusentryclick(View v){
	    	if(v.getId() == R.id.button4){
	    		Intent i = new Intent(adminmenu.this,busentry.class);
	    		startActivity(i);
	    	}
	    	
	    }

}
