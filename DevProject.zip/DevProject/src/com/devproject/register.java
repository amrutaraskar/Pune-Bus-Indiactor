package com.devproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.view.View.OnClickListener;

public class register extends Activity {

	  private RadioGroup radiogroup;
	  private RadioButton radiobutton;
	  private Button btnsubmit;

	  @Override
	  public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);

		addListenerOnButton();

	  }

	  public void addListenerOnButton() {

		radiogroup = (RadioGroup) findViewById(R.id.radiogrp);
		btnsubmit = (Button) findViewById(R.id.submit);

		btnsubmit.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {

			        // get selected radio button from radioGroup
				int selectedId = radiogroup.getCheckedRadioButtonId();

			        radiobutton = (RadioButton) findViewById(selectedId);
			        
			        switch(radiobutton.getId()) {
			             case R.id.radioButton1:
			             {
			            	 Intent i1 = new Intent(register.this, stdpay.class);
			     			 startActivity(i1);
			             }
			             break;
			             
			             case R.id.radioButton2:
			             {
			            	 Intent i2 = new Intent(register.this, emppay.class);
			     			 startActivity(i2);
			             }
			             break;
			             
			             case R.id.radioButton3:
			             {
			            	 Intent i2 = new Intent(register.this, clgpay.class);
			     			 startActivity(i2);
			             }
			             break;
			    }
			}

		});

	  }
	}